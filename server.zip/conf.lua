function love.conf(t)
    t.window.title = "server"
    t.console = true
end