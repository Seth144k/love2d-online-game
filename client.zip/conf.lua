function love.conf(t)
    t.window.title = "client"
    t.console = false
end